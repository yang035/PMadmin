<!-- /.footer -->
<div class="tiny-footer">
    <!-- tiny footer -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                <p>Copyright &copy; 2017.版权所有者   备案号 | 网警</p>
            </div>
        </div>
    </div>
</div>
<!-- /.tiny footer -->
<!-- back to top icon -->
<a href="#0" class="cd-top" title="Go to top">Top</a>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="__ADMIN_JS__/home/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="__ADMIN_JS__/home/js/bootstrap.min.js"></script>
<script type="text/javascript" src="__ADMIN_JS__/home/js/menumaker.js"></script>
<!-- animsition -->
<script type="text/javascript" src="__ADMIN_JS__/home/js/animsition.js"></script>
<script type="text/javascript" src="__ADMIN_JS__/home/js/animsition-script.js"></script>
<!-- sticky header -->
<script type="text/javascript" src="__ADMIN_JS__/home/js/jquery.sticky.js"></script>
<script type="text/javascript" src="__ADMIN_JS__/home/js/sticky-header.js"></script>
<!-- slider script -->
<script type="text/javascript" src="__ADMIN_JS__/home/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="__ADMIN_JS__/home/js/slider-carousel.js"></script>
<script type="text/javascript" src="__ADMIN_JS__/home/js/service-carousel.js"></script>
<!-- Back to top script -->
<script src="__ADMIN_JS__/home/js/back-to-top.js" type="text/javascript"></script>
</body>
</html>

