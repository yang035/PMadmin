<h1>欢迎首页</h1>
{include file="block/layui" /}