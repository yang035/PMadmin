{include file="home_block/header" /}
{__CONTENT__}
{include file="home_block/footer" /}