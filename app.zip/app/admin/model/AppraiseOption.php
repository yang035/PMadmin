<?php
namespace app\admin\model;

use think\Model;
class AppraiseOption extends Model
{
}
