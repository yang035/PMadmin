<?php
namespace app\admin\model;

use think\Model;

class AdminMenuLang extends Model
{
    // 自动写入时间戳
    protected $autoWriteTimestamp = false;
}
