<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/30
 * Time: 17:16
 */

namespace app\admin\model;


use think\Model;

class Bid extends Model
{
    protected $autoWriteTimestamp = 'datetime';

}