<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16
 * Time: 11:01
 */

namespace app\admin\model;


use think\Model;

class AdminUserDefault extends Model
{

}