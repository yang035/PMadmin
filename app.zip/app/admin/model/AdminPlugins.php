<?php
namespace app\admin\model;

use think\Model;
use think\Loader;

class AdminPlugins extends Model
{
    // 定义时间戳字段名
    protected $createTime = 'ctime';
    protected $updateTime = 'mtime';

    // 自动写入时间戳
    protected $autoWriteTimestamp = true;

    // 写入时,转JSON
    public function setConfigAttr($value)
    {
        if (empty($value)) return '';
        return json_encode($value, 1);
    }

    /**
     * 获取插件配置信息
     * @param  string $name 配置名
     * @param  bool $update 是否更新缓存
     * @return mixed
     */
    public static function getConfig($name = '', $update = false)
    {
        $result = cache('plugins_config');
        if (!$result || $update == true) {
            $rows = self::where('status', 2)->column('name,config', 'name');
            $result = [];
            foreach ($rows as $k => $r) {
                if (empty($r)) {
                    continue;
                }
                $config = json_decode($r, 1);
                if (!is_array($config)) {
                    continue;
                }
                foreach ($config as $rr) {
                    switch ($rr['type']) {
                        case 'array':
                        case 'checkbox':
                            $result['plugins_'.$k][$rr['name']] = parse_attr($rr['value']);
                            break;
                        default:
                            $result['plugins_'.$k][$rr['name']] = $rr['value'];
                            break;
                    }
                }
            }
            cache('plugins_config', $result);
        }
        return $name != '' ? $result[$name] : $result;
    }

    /**
     * 设计并生成标准插件结构
     * @return bool
     */
    public function design($data = [])
    {
        $path = ROOT_PATH.'plugins'.DS.$data['name'].DS;
        $dir_list = parse_attr($data['dir']);

        if (in_array('admin', $dir_list) !== false) {
            $dir_list[] = 'view/admin/index';
        }
        if (in_array('home', $dir_list) !== false) {
            $dir_list[] = 'view/home/index';
        }
        $dir_list[] = 'view/widget';
        
        unset($data['dir']);
        // 如果存在配置信息，重组数据
        if (isset($data['config']) && !empty($data['config'])) {
            $config = [];
            $input_type = ['array', 'switch', 'radio', 'checkbox', 'select'];
            foreach ($data['config'] as $k => $v) {
                $sort = (int)$v['sort'];
                if (in_array($v['type'], $input_type) != false && empty($v['options'])) {
                    $this->error = '['.$v['title'].']的配置选项不完整！';
                    return false;
                }
                if ($v['options']) {
                    $v['options'] = parse_attr($v['options']);
                }
                $config[$sort] = $v;
            }
            sort($config);
            $data['config'] = json_encode($config, 1);
        } else {
            $config = $data['config'] = '';
        }

        $data['status'] = 0;
        $data['icon'] = ROOT_DIR.'plugins/'.$data['name'].'/'.$data['name'].'.png';
        // 验证
        $valid = Loader::validate('app\admin\validate\Plugins');
        if($valid->check($data) !== true) {
            $this->error = $valid->getError();
            return false;
        }

        if (is_dir($path)) {
            $this->error = '插件目录已存在！';
            return false;
        }
        
        if (!self::create($data)) {
            $this->error = '插件生成失败！';
            return false;
        }
        // 生成插件目录
        mkdir($path, 0777, true);
        // 生成插件信息
        $this->mkInfo($path, $data, $config);
        // 生成独立配置文件
        // $this->mkConfig($path, $config);
        // 生成sql文件
        if (in_array('sql', $dir_list) !== false) {
            $this->mkSql($path);
        }
        // 生成菜单文件
        $this->mkMenu($path, $data);
        // 生成钩子文件
        $this->mkHook($path, $data);
        // 生成目录结构
        $this->mkDir($path, $dir_list);
        // 生成默认示例控制器
        $this->mkExample($path, $data);

        copy(ROOT_PATH.'static'.DS.'admin'.DS.'image'.DS.'app.png', ROOT_PATH.'plugins'.DS.$data['name'].DS.$data['name'].'.png');
        // 生成说明文档
        // $this->mkReadme($path, $data);
        return true;
    }

    /**
     * 生成插件配置
     * @param string $path 插件完整路径
     * @param string $config 插件配置信息
     */
    public function mkConfig($path = '', $config = [])
    {
        if (empty($config)) {
            $config = [];
        }
        // 美化数组格式
        $config = var_export($config, true);
        $config = str_replace(['array (', ')'], ['[', ']'], $config);
        $config = preg_replace("/(\s*?\r?\n\s*?)+/", "\n", $config);
        $str = "<?php\n//格式['sort' => '100','title' => '配置标题','name' => '配置名称','type' => '配置类型','options' => '配置选项','value' => '配置默认值', 'tips' => '配置提示'] 各参数设置可参考管理后台->系统->系统功能->配置管理->添加\nreturn ".$config.";\n";
        file_put_contents($path . 'config.php', $str);  
    }

    /**
     * 生成默认示例控制器
     * @param string $path 插件完整路径
     * @param string $data 插件基本信息
     */
    public function mkExample($path = '', $data = [])
    {
        if (is_dir($path.'admin')) {
            $admin = "<?php\nnamespace plugins\\".$data["name"]."\\admin;\nuse app\common\admin\Common;\ndefined('IN_SYSTEM') or die('Access Denied');\n\nclass Index extends Common\n{\n    public function index()\n    {\n        return ".'$this->fetch()'.";\n    }\n}";
            file_put_contents($path . 'admin'.DS.'Index.php', $admin);
            file_put_contents($path.'view'.DS.'admin'.DS.'index'.DS.'index.php', "<?php defined('IN_SYSTEM') or die('Access Denied');/* 防止模板被盗 */?>\n{include file=\"admin@block/layui\" /}");
        }
        if (is_dir($path.'home')) {
            $home = "<?php\nnamespace plugins\\".$data["name"]."\\home;\nuse app\common\admin\Common;\ndefined('IN_SYSTEM') or die('Access Denied');\n\nclass Index extends Common\n{\n    public function index()\n    {\n        return ".'$this->fetch()'.";\n    }\n}";
            file_put_contents($path . 'home'.DS.'Index.php', $home);
            file_put_contents($path.'view'.DS.'home'.DS.'index'.DS.'index.php', '<?php defined("IN_SYSTEM") or die("Access Denied");/* 防止模板被盗 */?>');
        }
    }

    /**
     * 生成目录结构
     * @param string $path 插件完整路径
     * @param array $list 目录列表
     */
    public function mkDir($path = '', $list = [])
    {
        foreach ($list as $dir) {
            if (!is_dir($path . $dir)) {
                // 创建目录
                mkdir($path . $dir, 0755, true);
            }
        }
    }

    /**
     * 生成SQL文件
     * @param string $path 插件完整路径
     */
    public function mkSql($path = '')
    {
        if (!is_dir($path . 'sql')) {
            mkdir($path . 'sql', 0755, true);
        }
        file_put_contents($path . 'sql'.DS.'install.sql', "/*\n sql安装文件\n*/");
        file_put_contents($path . 'sql'.DS.'uninstall.sql', "/*\n sql卸载文件\n*/");
    }

    /**
     * 生成钩子文件
     * @param string $path 插件完整路径
     * @param string $data 插件基本信息
     */
    public function mkHook($path = '', $data = [])
    {
        $params = '$params';
        $hooks = '$hooks';
        $code = <<<INFO
<?php
namespace plugins\\{$data['name']};
use app\common\controller\Plugins;
defined('IN_SYSTEM') or die('Access Denied');
class {$data['name']} extends Plugins
{
    /**
     * @var array 插件钩子清单
     */
    public $hooks = [
        // 钩子名称 => 钩子说明【系统钩子，说明不用填写】
        'system_admin_tips',
    ];

    /**
     * system_admin_tips钩子方法
     * @param $params
     */
    public function systemAdminTips(&$params)
    {
        echo '这是插件[{$data['name']}]的示例！[我在这儿：/plugins/{$data['name']}/{$data['name']}.php]<br>';
    }

    /**
     * 安装前的业务处理，可在此方法实现，默认返回true
     * @return bool
     */
    public function install()
    {
        return true;
    }

    /**
     * 安装后的业务处理，可在此方法实现，默认返回true
     * @return bool
     */
    public function installAfter()
    {
        return true;
    }

    /**
     * 卸载前的业务处理，可在此方法实现，默认返回true
     * @return bool
     */
    public function uninstall()
    {
        return true;
    }

    /**
     * 卸载后的业务处理，可在此方法实现，默认返回true
     * @return bool
     */
    public function uninstallAfter()
    {
        return true;
    }

}
INFO;
        file_put_contents($path.$data['name'].'.php', $code);
    }

    public function mkMenu($path = '', $data = [])
    {
        $menus = <<<INFO
<?php
return [
    [
        'title'         => '插件功能1',
        'icon'          => 'aicon ai-shezhi',
        'url'           => 'admin/plugins/run',
        'param'         => '_p={$data['name']}&_c=index&_a=index',
        'target'        => '_self',
        'sort'          => 0,
        'childs'        => [
            [
                'title'         => '插件功能1-1',
                'icon'          => 'aicon ai-shezhi',
                'url'           => 'admin/plugins/run',
                'param'         => '_p={$data['name']}&_c=index&_a=index',
                'target'        => '_self',
                'sort'          => 0,
                'childs'        => [
                    [
                        'title'         => '插件功能1-1-1',
                        'icon'          => 'aicon ai-shezhi',
                        'url'           => 'admin/plugins/run',
                        'param'         => '_p={$data['name']}&_c=index&_a=index',
                        'target'        => '_self',
                        'sort'          => 0,
                    ],
                    [
                        'title'         => '插件功能1-1-2',
                        'icon'          => 'aicon ai-shezhi',
                        'url'           => 'admin/plugins/run',
                        'param'         => '_p={$data['name']}&_c=index&_a=index',
                        'target'        => '_self',
                        'sort'          => 0,
                    ],
                    [
                        'title'         => '插件功能1-1-3',
                        'icon'          => 'aicon ai-shezhi',
                        'url'           => 'admin/plugins/run',
                        'param'         => '_p={$data['name']}&_c=index&_a=index',
                        'target'        => '_self',
                        'sort'          => 0,
                    ],
                ],
            ],
            [
                'title'         => '插件功能2',
                'icon'          => 'aicon ai-shezhi',
                'url'           => 'admin/plugins/run',
                'param'         => '_p={$data['name']}&_c=index&_a=index',
                'target'        => '_self',
                'sort'          => 0,
            ],
            [
                'title'         => '插件功能3',
                'icon'          => 'aicon ai-shezhi',
                'url'           => 'admin/plugins/run',
                'param'         => '_p={$data['name']}&_c=index&_a=index',
                'target'        => '_self',
                'sort'          => 0,
            ],
        ],
    ],
];
INFO;
        file_put_contents($path . 'menu.php', $menus);
    }

    public function mkInfo($path = '', $data = [], $config = [])
    {
        if (empty($config)) {
            $config = [];
        }
        // 美化数组格式
        $config = var_export($config, true);
        $config = str_replace(['array (', ')'], ['[', ']'], $config);
        $config = preg_replace("/(\s*?\r?\n\s*?)+/", "\n", $config);
        $code = <<<INFO
<?php
return [
    // 插件名[必填]
    'name'        => '{$data['name']}',
    // 插件标题[必填]
    'title'       => '{$data['title']}',
    // 模块唯一标识[必填]，格式：插件名.[应用市场ID].plugins.[应用市场分支ID]
    'identifier'  => '{$data['identifier']}',
    // 插件图标[必填]
    'icon'        => '/plugins/{$data['name']}/{$data['name']}.png',
    // 插件描述[选填]
    'intro' => '{$data['intro']}',
    // 插件作者[必填]
    'author'      => '{$data['author']}',
    // 作者主页[选填]
    'author_url'  => '{$data['url']}',
    // 版本[必填],格式采用三段式：主版本号.次版本号.修订版本号
    // 主版本号【位数变化：1-99】：当模块出现大更新或者很大的改动，比如整体架构发生变化。此版本号会变化。
    // 次版本号【位数变化：0-999】：当模块功能有新增或删除，此版本号会变化，如果仅仅是补充原有功能时，此版本号不变化。
    // 修订版本号【位数变化：0-999】：一般是 Bug 修复或是一些小的变动，功能上没有大的变化，修复一个严重的bug即发布一个修订版。
    'version'     => '{$data['version']}',
    // 原始数据库表前缀,插件带sql文件时必须配置
    'db_prefix' => 'db_',
    //格式['sort' => '100','title' => '配置标题','name' => '配置名称','type' => '配置类型','options' => '配置选项','value' => '配置默认值', 'tips' => '配置提示'] 各参数设置可参考管理后台->系统->系统功能->配置管理->添加
    'config'    => {$config},
];
INFO;
        file_put_contents($path.'info.php', $code);
    }
}
