<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/30
 * Time: 9:43
 */

namespace app\admin\validate;


use think\Validate;

class ProjectScorelog extends Validate
{
    //定义验证规则
    protected $rule = [
    ];

    //定义验证提示
    protected $message = [
    ];

}