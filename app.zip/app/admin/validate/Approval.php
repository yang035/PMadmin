<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/30
 * Time: 17:17
 */

namespace app\admin\validate;


use think\Validate;

class Approval extends Validate
{

}